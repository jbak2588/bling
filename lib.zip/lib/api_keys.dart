// lib/api_keys.dart

//  const String googleApiKey = "AIzaSyCGr0wgQ67ezSwO5pLowMx6J8emksSaemo"; // 빠몽님의 실제 API 키를 여기에 붙여넣어 주세요.

class ApiKeys {
  static const googleApiKey =
      'AIzaSyCGr0wgQ67ezSwO5pLowMx6J8emksSaemo'; // ← API 키 4개에 해당하는 키 입력
}
