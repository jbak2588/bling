// ===================== DocHeader =====================
// [기획 요약]
// - 상점 상세 정보, 이미지 갤러리, 채팅 연동, 신뢰 등급, 연락처, 영업시간 등 다양한 필드 지원.
//
// [실제 구현 비교]
// - 상세 정보, 이미지 갤러리, 채팅 연동, 신뢰 등급, 연락처, 영업시간 등 모든 주요 기능 정상 동작.
// - UI/UX 완비, 채팅방 생성 및 상점주 정보 연동 구현됨.
//
// [개선 제안]
// - KPI/통계/프리미엄 기능 실제 구현 필요(조회수, 리뷰, 부스트 등).
// - 신고/차단/신뢰 등급 UI 노출 및 기능 강화, 알림/리뷰 UX 개선.
// =====================================================
// lib/features/local_stores/screens/shop_detail_screen.dart
// ===================== DocHeader =====================
// [기획 요약]
// - 상점 상세 정보, 이미지 갤러리, 채팅 연동, 신뢰 등급, 연락처, 영업시간 등 다양한 필드 지원.
//
// [실제 구현 비교]
// - 상세 정보, 이미지 갤러리, 채팅 연동, 신뢰 등급, 연락처, 영업시간 등 모든 주요 기능 정상 동작.
// - UI/UX 완비, 채팅방 생성 및 상점주 정보 연동 구현됨.
//
// [개선 제안]
// - KPI/통계/프리미엄 기능 실제 구현 필요(조회수, 리뷰, 부스트 등).
// - 신고/차단/신뢰 등급 UI 노출 및 기능 강화, 알림/리뷰 UX 개선.
// =====================================================
// [작업 이력 (2025-11-02)]
// 1. (Task 1) '조회수(KPI)' 증가: initState에서 repository.incrementShopView(shop.id) 호출.
// 2. (Task 1) '리뷰/평점' 표시: '_buildReviewSection' 위젯을 추가하여 평점 요약 및 리뷰 목록(Stream) 표시.
// 3. (Task 4) '인증 배지' UI: 가게 이름 옆에 'trustLevelVerified' 값에 따라 인증 아이콘(Icons.verified) 표시.
// 4. (Task 5) '대표 상품' UI: 'products' 리스트를 'Wrap' 및 'Chip' 위젯을 사용해 태그 형태로 표시.
// 5. (Task 6) 'Jobs' 연동:
//    - 생성자에서 'userModel'을 받도록 수정.
//    - 가게 주인(isOwner)일 경우 AppBar에 '알바 구하기'(Icons.work_outline) 버튼 표시.
//    - 버튼 클릭 시 'CreateJobScreen'으로 가게 이름/위치 정보를 자동 입력하여 이동.
// =====================================================
// lib/features/local_stores/screens/shop_detail_screen.dart

import 'package:bling_app/features/local_stores/models/shop_model.dart';
import 'package:bling_app/core/models/user_model.dart';
import 'package:bling_app/features/chat/data/chat_service.dart';
import 'package:bling_app/features/chat/screens/chat_room_screen.dart';
import 'package:bling_app/features/local_stores/models/shop_review_model.dart'; // [추가]
import 'package:bling_app/features/local_stores/data/shop_repository.dart';
import 'package:bling_app/features/local_stores/screens/edit_shop_screen.dart';
import 'package:bling_app/features/jobs/screens/create_job_screen.dart'; // [추가] Jobs 연동
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
// [추가] 리뷰 작성을 위한 위젯 (예: flutter_rating_bar)
// import 'package:flutter_rating_bar/flutter_rating_bar.dart';
// [추가] 날짜 포매팅을 위한 intl

class ShopDetailScreen extends StatefulWidget {
  final ShopModel shop;
  final UserModel? userModel; // [추가]
  const ShopDetailScreen({super.key, required this.shop, this.userModel});

  @override
  State<ShopDetailScreen> createState() => _ShopDetailScreenState();
}

class _ShopDetailScreenState extends State<ShopDetailScreen> {
  final ShopRepository _repository = ShopRepository();
  final ChatService _chatService = ChatService();
  final String? _currentUserId = FirebaseAuth.instance.currentUser?.uid;

  // V V V --- [수정] 이미지 슬라이더와 썸네일을 동기화하기 위한 PageController 추가 --- V V V
  late final PageController _pageController;
  int _currentImageIndex = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    // [추가] 상세 페이지 진입 시 조회수 1 증가
    _repository.incrementShopView(widget.shop.id);
  }

  @override
  void dispose() {
    _pageController.dispose(); // PageController 메모리 해제
    super.dispose();
  }

  void _startChat(BuildContext context) async {
    try {
      final chatId = await _chatService.createOrGetChatRoom(
        otherUserId: widget.shop.ownerId,
        shopId: widget.shop.id,
        shopName: widget.shop.name,
        shopImage: widget.shop.imageUrls.isNotEmpty
            ? widget.shop.imageUrls.first
            : null,
      );

      final otherUser =
          await _chatService.getOtherUserInfo(widget.shop.ownerId);

      if (!context.mounted) return;

      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => ChatRoomScreen(
            chatId: chatId,
            otherUserName: otherUser.nickname,
            otherUserId: otherUser.uid,
            productTitle: widget.shop.name,
          ),
        ),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('localStores.detail.startChatFail'
                  .tr(namedArgs: {'error': e.toString()})),
              backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _deleteShop() async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('localStores.detail.deleteTitle'.tr()),
        content: Text('localStores.detail.deleteContent'.tr()),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text('common.cancel'.tr())),
          TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: Text('common.delete'.tr(),
                  style: const TextStyle(color: Colors.red))),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      try {
        await _repository.deleteShop(widget.shop.id);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('localStores.detail.deleteSuccess'.tr()),
            backgroundColor: Colors.green));
        Navigator.of(context).pop();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('localStores.detail.deleteFail'
                .tr(namedArgs: {'error': e.toString()})),
            backgroundColor: Colors.red));
      }
    }
  }

// V V V --- [수정] 이미지 슬라이더 + 하단 썸네일 UI --- V V V
  Widget _buildImageSlider(List<String> images) {
    if (images.isEmpty) {
      return Container(
        height: 250,
        color: Colors.grey.shade200,
        child: const Icon(Icons.storefront, size: 80, color: Colors.grey),
      );
    }
    return Column(
      children: [
        // --- 1. 메인 이미지 슬라이더 ---
        GestureDetector(
          onTap: () {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => FullScreenImageViewer(
                imageUrls: images,
                initialIndex: _currentImageIndex,
              ),
            ));
          },
          child: Container(
            height: 250,
            color: Colors.black,
            child: PageView.builder(
              controller: _pageController, // 컨트롤러 연결
              itemCount: images.length,
              onPageChanged: (index) {
                setState(() => _currentImageIndex = index);
              },
              itemBuilder: (context, index) {
                return Image.network(images[index], fit: BoxFit.contain);
              },
            ),
          ),
        ),

        // --- 2. 하단 썸네일 목록 ---
        if (images.length > 1)
          Container(
            height: 80,
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: images.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    // 썸네일을 탭하면 메인 슬라이더가 해당 이미지로 이동
                    _pageController.animateToPage(
                      index,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                    );
                  },
                  child: Container(
                    width: 70,
                    margin: const EdgeInsets.symmetric(horizontal: 4.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: _currentImageIndex == index
                            ? Theme.of(context).primaryColor
                            : Colors.transparent,
                        width: 2,
                      ),
                      image: DecorationImage(
                        image: NetworkImage(images[index]),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }
  // ^ ^ ^ --- 여기까지 이식 --- ^ ^ ^

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<ShopModel>(
      stream: _repository.getShopStream(widget.shop.id),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(
              body: Center(child: CircularProgressIndicator()));
        }
        final shop = snapshot.data!;
        final isOwner = shop.ownerId == _currentUserId;

        return Scaffold(
          appBar: AppBar(
            title: Text(shop.name),
            actions: [
              // [추가] 'Jobs' 연동 (알바 구하기 버튼)
              if (isOwner && widget.userModel != null)
                IconButton(
                  icon: const Icon(Icons.work_outline),
                  tooltip: 'jobs.create.title'.tr(), // "알바 구하기"
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => CreateJobScreen(
                          userModel: widget.userModel!,
                          // [자동 채우기] 가게 정보 전달
                          initialCompanyName: shop.name,
                          initialLocation: shop.locationName,
                          initialGeoPoint: shop.geoPoint,
                          initialLocationParts: shop.locationParts,
                        ),
                      ),
                    );
                  },
                ),
              if (isOwner)
                IconButton(
                  icon: const Icon(Icons.edit_note_outlined),
                  tooltip: 'localStores.edit.tooltip'.tr(),
                  onPressed: () {
                    Navigator.of(context)
                        .push(
                          MaterialPageRoute(
                              builder: (_) => EditShopScreen(shop: shop)),
                        )
                        .then((_) => setState(() {}));
                  },
                ),
              if (isOwner)
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  tooltip: 'localStores.detail.deleteTooltip'.tr(),
                  onPressed: _deleteShop,
                ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 100.0),
            children: [
              // [수정] 기존 Image.network를 새로 이식한 _buildImageSlider로 교체
              _buildImageSlider(shop.imageUrls),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Text(shop.name,
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(fontWeight: FontWeight.bold)),
                        ),
                        // [추가] 인증 배지
                        if (shop.trustLevelVerified) ...[
                          const SizedBox(width: 8),
                          Icon(Icons.verified,
                              color: Theme.of(context).primaryColor, size: 24),
                        ]
                      ],
                    ),
                    const SizedBox(height: 8),
                    _buildInfoRow(context, Icons.location_on_outlined,
                        shop.locationName ?? 'localStores.noLocation'.tr()),
                    const SizedBox(height: 4),
                    _buildInfoRow(
                        context, Icons.watch_later_outlined, shop.openHours),
                    const SizedBox(height: 4),
                    _buildInfoRow(
                        context, Icons.phone_outlined, shop.contactNumber),
                    const Divider(height: 32),
                    // [추가] 대표 상품/서비스 칩
                    if (shop.products != null && shop.products!.isNotEmpty) ...[
                      Text('localStores.detail.products'.tr(), // "대표 상품 및 서비스"
                          style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8.0, // 칩 사이의 가로 간격
                        runSpacing: 4.0, // 칩 사이의 세로 간격
                        children: shop.products!
                            .map((product) => Chip(label: Text(product.trim())))
                            .toList(),
                      ),
                      const Divider(height: 32),
                    ],
                    Text('localStores.detail.description'.tr(),
                        style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 8),
                    Text(shop.description,
                        style: const TextStyle(fontSize: 16, height: 1.5)),
                    const Divider(height: 32),
                    // [추가] 리뷰 섹션
                    Text(
                        'localStores.detail.reviews'.tr(
                            namedArgs: {'count': shop.reviewCount.toString()}),
                        style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 8),
                    _buildReviewSection(shop), // 리뷰 목록 및 작성 UI
                    const Divider(height: 32),
                    // [끝] 리뷰 섹션
                    _buildOwnerInfo(shop.ownerId),
                  ],
                ),
              )
            ],
          ),
          bottomNavigationBar: isOwner
              ? null
              : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: () => _startChat(context),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: Text('localStores.detail.inquire'.tr()),
                  ),
                ),
        );
      },
    );
  }

  Widget _buildInfoRow(BuildContext context, IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: Colors.grey[600], size: 18),
        const SizedBox(width: 8),
        Expanded(
            child: Text(text,
                style: TextStyle(fontSize: 15, color: Colors.grey[800]))),
      ],
    );
  }

  Widget _buildOwnerInfo(String userId) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || !snapshot.data!.exists) {
          return ListTile(title: Text('localStores.detail.noOwnerInfo'.tr()));
        }
        final user = UserModel.fromFirestore(snapshot.data!);
        return Card(
          elevation: 0,
          color: Colors.grey.shade100,
          child: ListTile(
            leading: CircleAvatar(
              backgroundImage:
                  (user.photoUrl != null && user.photoUrl!.isNotEmpty)
                      ? NetworkImage(user.photoUrl!)
                      : null,
              child: (user.photoUrl == null || user.photoUrl!.isEmpty)
                  ? const Icon(Icons.person)
                  : null,
            ),
            title: Text(user.nickname,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(user.locationName ?? ''),
          ),
        );
      },
    );
  }

  // [추가] 리뷰 섹션 UI 빌더
  Widget _buildReviewSection(ShopModel shop) {
    // (가정) 현재 사용자가 리뷰를 작성할 수 있는지 (주인X, 구매이력O 등)
    final bool canReview = shop.ownerId != _currentUserId;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // --- 별점 요약 ---
        Row(
          children: [
            Text(shop.averageRating.toStringAsFixed(1),
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(color: Colors.black87)),
            const SizedBox(width: 8),
            // (가정) RatingBar.builder 같은 위젯 사용
            Text(
                "★" * shop.averageRating.round() +
                    "☆" * (5 - shop.averageRating.round()),
                style: TextStyle(color: Colors.yellow[700], fontSize: 20)),
            const SizedBox(width: 8),
            Text('localStores.detail.reviews'
                .tr(namedArgs: {'count': shop.reviewCount.toString()})),
          ],
        ),
        const SizedBox(height: 16),

        // --- 리뷰 작성 버튼 ---
        if (canReview)
          OutlinedButton.icon(
            icon: const Icon(Icons.rate_review_outlined),
            label: Text('localStores.detail.writeReview'.tr()),
            onPressed: () {
              _showWriteReviewDialog(shop.id);
            },
          ),
        const SizedBox(height: 16),

        // --- 리뷰 목록 ---
        StreamBuilder<List<ShopReviewModel>>(
          stream: _repository.fetchReviews(shop.id),
          builder: (context, snapshot) {
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('localStores.detail.noReviews'.tr()));
            }
            final reviews = snapshot.data!;
            return ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: reviews.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final review = reviews[index];
                return ListTile(
                  title: Text("★" * review.rating + "☆" * (5 - review.rating),
                      style: TextStyle(color: Colors.yellow[700])),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(review.comment),
                      const SizedBox(height: 4),
                      // (개선) userId 대신 닉네임 표시 필요 (FutureBuilder 사용)
                      Text(
                          "by ${review.userId.substring(0, 6)}... · ${DateFormat.yMd().format(review.createdAt.toDate())}",
                          style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  // [추가] 리뷰 작성 다이얼로그 (간단 예시)
  void _showWriteReviewDialog(String shopId) {
    // (개선) 이 부분은 별도 Stateful 위젯으로 분리해야 함 (Rating, TextEditingController)
    // 아래는 단순화된 예시
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('localStores.detail.writeReview'.tr()),
        content: Text('localStores.detail.reviewDialogContent'
            .tr()), // 실제로는 별점 선택 + 텍스트 입력 필드
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('common.cancel'.tr())),
          TextButton(
              onPressed: () {
                /* (개선) _repository.addReview(...) 호출 */ Navigator.of(context)
                    .pop();
              },
              child: Text('common.submit'.tr())),
        ],
      ),
    );
  }
}

// V V V --- [이식] 전체 화면 이미지 뷰어 (핀치 앤 줌 기능 포함) --- V V V
class FullScreenImageViewer extends StatefulWidget {
  final List<String> imageUrls;
  final int initialIndex;

  const FullScreenImageViewer({
    super.key,
    required this.imageUrls,
    this.initialIndex = 0,
  });

  @override
  State<FullScreenImageViewer> createState() => _FullScreenImageViewerState();
}

class _FullScreenImageViewerState extends State<FullScreenImageViewer> {
  late final PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: _currentIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: Text('${_currentIndex + 1} / ${widget.imageUrls.length}'),
        centerTitle: true,
      ),
      body: PhotoViewGallery.builder(
        pageController: _pageController,
        itemCount: widget.imageUrls.length,
        builder: (context, index) {
          return PhotoViewGalleryPageOptions(
            imageProvider: NetworkImage(widget.imageUrls[index]),
            minScale: PhotoViewComputedScale.contained,
            maxScale: PhotoViewComputedScale.covered * 2,
          );
        },
        onPageChanged: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }
}
// ^ ^ ^ --- 여기까지 이식 --- ^ ^ ^
