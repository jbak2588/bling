// lib/features/main_screen/home_screen.dart

/// [기획 문서: 00 Mainscreen & 런처 & Tab & Drawer QA.md]
/// - 기획 요약: 메인 화면의 AppBar, 슬라이드 탭, Drawer, BottomNavigationBar, 주요 컴포넌트(FeedCard, Comment Bubble, Chat Bubble, FAB 등) 구조와 반응형/애니메이션/접근성 정책
/// - 실제 코드 기능: 다양한 피드/카드/모듈 위젯을 통합하여 메인 홈 화면을 구성, 각 기능별 화면 import, 반응형 UI 및 다양한 카드/버블/버튼 구현
/// - 비교: 기획의 주요 컴포넌트와 구조가 실제 코드에서 위젯/화면으로 세분화되어 구현됨. 접근성/애니메이션 등은 일부 위젯에서 적용됨
///
/// [상세 분석 및 코멘트]
/// 1. AppBar에 전달되는 주요 파라미터
///   - userModel: 사용자 맞춤 정보(프로필, 신뢰등급 등) 제공, 지역 기반 서비스와 연동
///   - activeLocationFilter: Kab/Kec/Kel 등 다양한 지역 단위로 필터링, "My Town" 드롭다운에 직접 반영
///   - onIconTap: 기능별 아이콘 클릭 시 화면 전환, 네비게이션 UX와 연결
///   → AppBar는 개인화·지역화·서비스 접근성의 핵심 진입점
///
/// 2. My Town의 다변화
///   - 단순 텍스트가 아닌 드롭다운으로 Kab/Kec/Kel 등 다양한 지역 단위 선택 가능
///   - 사용자의 활동 범위 세밀 조정, 모든 기능(피드/마켓/친구찾기 등)과 연동
///   - 다국어 지원과 결합되어 현지화 및 글로벌 확장성 강화
///
/// 3. locationParts의 Kab 필터 최초 적용 이유
///   - Kab(카부파텐)은 인도네시아 지역 서비스의 핵심 단위, 생활권 정보 탐색에 최적
///   - DB 구조와 연동되어 데이터 일관성·검색 효율성 향상
///   - 향후 광고·프로모션·추천 등 수익화 전략에 직접 활용 가능
///
/// [제안 및 결론]
/// - AppBar 파라미터 설계는 지역 기반 슈퍼앱의 UX/데이터 구조와 직결, 개인화·지역화·수익화 모두 강화
/// - Kab 필터 도입은 사용자 경험과 비즈니스 전략 모두에서 매우 중요한 결정
/// - 향후 개선: 지역 단위별 추천·광고·커뮤니티 연계, UI/UX(지도 시각화, 애니메이션 등) 강화, 데이터 기반 KPI/Analytics 연동
/// - Todo: 통합 피드 스크롤 다운 후 즉시 화면 맨 위로 이동 기능 필요
library;

import 'package:bling_app/features/shared/grab_widgets.dart';

import 'package:bling_app/core/models/feed_item_model.dart';
import 'package:bling_app/core/models/user_model.dart';
import 'package:bling_app/features/main_feed/data/feed_repository.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:cached_network_image/cached_network_image.dart';

// 모든 card 위젯과 그에 필요한 model들을 import 합니다.
import 'package:bling_app/features/local_news/widgets/post_card.dart';
import 'package:bling_app/features/local_news/models/post_model.dart';
import 'package:bling_app/features/marketplace/widgets/product_card.dart';
import 'package:bling_app/features/marketplace/models/product_model.dart';
import 'package:bling_app/features/jobs/widgets/job_card.dart';
import 'package:bling_app/features/jobs/models/job_model.dart';
import 'package:bling_app/features/auction/widgets/auction_card.dart';
import 'package:bling_app/features/auction/models/auction_model.dart';
import 'package:bling_app/features/clubs/widgets/club_post_card.dart';
import 'package:bling_app/features/clubs/models/club_post_model.dart';
import 'package:bling_app/features/clubs/models/club_model.dart';
import 'package:bling_app/features/lost_and_found/widgets/lost_item_card.dart';
import 'package:bling_app/features/lost_and_found/models/lost_item_model.dart';
import 'package:bling_app/features/pom/models/short_model.dart';
import 'package:bling_app/features/real_estate/widgets/room_card.dart';
import 'package:bling_app/features/real_estate/models/room_listing_model.dart';
import 'package:bling_app/features/local_stores/widgets/shop_card.dart';
import 'package:bling_app/features/local_stores/models/shop_model.dart';
import 'package:bling_app/features/find_friends/widgets/findfriend_card.dart';

// 아이콘 그리드에서 사용할 각 기능별 화면을 import 합니다.
import 'package:bling_app/features/local_news/screens/local_news_screen.dart';
import 'package:bling_app/features/marketplace/screens/marketplace_screen.dart';
import 'package:bling_app/features/clubs/screens/clubs_screen.dart';
import 'package:bling_app/features/find_friends/screens/find_friends_screen.dart';
import 'package:bling_app/features/jobs/screens/jobs_screen.dart';
import 'package:bling_app/features/local_stores/screens/local_stores_screen.dart';
import 'package:bling_app/features/auction/screens/auction_screen.dart';
import 'package:bling_app/features/pom/screens/pom_screen.dart';
import 'package:bling_app/features/lost_and_found/screens/lost_and_found_screen.dart';
import 'package:bling_app/features/real_estate/screens/real_estate_screen.dart';

class MenuItem {
  final IconData icon;
  final String labelKey;
  final Widget screen;
  MenuItem({required this.icon, required this.labelKey, required this.screen});
}

class HomeScreen extends StatelessWidget {
  // (2) 검색 칩 위젯 헬퍼 - 디자인/텍스트 최신화
  Widget _searchChip(VoidCallback? onTap) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 44,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(999),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.06),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: const Row(
            children: [
              Icon(Icons.search),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  '이웃 , 소식, 장터, 일자리… 검색',  //TODO : 다국어 
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 접근성 대응: textScalerOf 기반 스케일 추출 유틸
  double effectiveTextScale(BuildContext context, {double basis = 16}) {
    final s = MediaQuery.textScalerOf(context);
    return s.scale(basis) / basis;
  }

  final UserModel? userModel;
  final Map<String, String?>? activeLocationFilter;
  final Function(Widget, String) onIconTap;

  final List<FeedItemModel> allFeedItems;
  final int currentIndex;

  const HomeScreen({
    super.key,
    required this.userModel,
    required this.activeLocationFilter,
    required this.onIconTap,
    this.allFeedItems = const [],
    this.currentIndex = 0,
    required this.onSearchChipTap,
  });

  final VoidCallback? onSearchChipTap;

  static final List<MenuItem> menuItems = [
    MenuItem(
        icon: Icons.newspaper_outlined,
        labelKey: 'main.tabs.localNews',
        screen: const LocalNewsScreen()),
    MenuItem(
        icon: Icons.storefront_outlined,
        labelKey: 'main.tabs.marketplace',
        screen: const MarketplaceScreen()),
    MenuItem(
        icon: Icons.groups_outlined,
        labelKey: 'main.tabs.clubs',
        screen: const ClubsScreen()),
    MenuItem(
        icon: Icons.favorite_border_outlined,
        labelKey: 'main.tabs.findFriends',
        screen: const FindFriendsScreen()),
    MenuItem(
        icon: Icons.work_outline,
        labelKey: 'main.tabs.jobs',
        screen: const JobsScreen()),
    MenuItem(
        icon: Icons.store_mall_directory_outlined,
        labelKey: 'main.tabs.localStores',
        screen: const LocalStoresScreen()),
    MenuItem(
        icon: Icons.gavel_outlined,
        labelKey: 'main.tabs.auction',
        screen: const AuctionScreen()),
    MenuItem(
        icon: Icons.star_outline,
        labelKey: 'main.tabs.pom',
        screen: const PomScreen()),
    MenuItem(
        icon: Icons.help_outline,
        labelKey: 'main.tabs.lostAndFound',
        screen: const LostAndFoundScreen()),
    MenuItem(
        icon: Icons.house_outlined,
        labelKey: 'main.tabs.realEstate',
        screen: const RealEstateScreen()),
  ];

  @override
  Widget build(BuildContext context) {
    // ===== 반응형 그리드/타일 사이즈 계산 (textScalerOf 사용) =====
    final size = MediaQuery.of(context).size;
    final width = size.width;
    final double tsFactor = effectiveTextScale(context); // ≈ textScaleFactor
    final String lang = context.locale.languageCode; // 'id' | 'ko' | 'en'
    final bool longLabelLang = (lang == 'id');

    // 5열 사용 조건: 화면폭 충분 + 텍스트가 너무 크지 않음(언어별 임계값)
    final bool force4 = width < 360 || tsFactor > (longLabelLang ? 1.10 : 1.15);
    final int gridCount = force4 ? 4 : 5;

    // SliverPadding/간격 기준으로 셀 폭 계산
    const double outerPad = 16; // 좌우 패딩
    const double crossGap = 8; // 열 간격
    final double tileWidth =
        (width - (outerPad * 2) - (crossGap * (gridCount - 1))) / gridCount;

    // 타일 높이: 5열일 때 낮게, 긴 라벨/큰 글자면 여유 +2dp
    double tileHeight = gridCount == 5 ? 98 : 104;
    if (longLabelLang) tileHeight += 2;
    if (tsFactor > 1.15) tileHeight += 2;

    final double childAspectRatio = tileWidth / tileHeight;

    // ✅ 탭 전환 콜백 준비: 주입받았으면 그걸 쓰고, 없으면 기존 플레이스홀더로 Fallback
    final VoidCallback? searchAction = onSearchChipTap;

    return CustomScrollView(
      slivers: [
        // ✅ AppBar 바로 아래, 얇은 검색 칩만 노출(입력은 Search 탭에서)
        SliverToBoxAdapter(child: _searchChip(searchAction)),

        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          sliver: SliverGrid.count(
            crossAxisCount: gridCount,
            crossAxisSpacing: crossGap,
            mainAxisSpacing: 12,
            childAspectRatio: childAspectRatio,
            children: menuItems.map((item) {
              return GrabIconTile(
                compact: gridCount == 5,
                icon: item.icon,
                label: item.labelKey.tr(),
                onTap: () {
                  // ⬇️ 기존 onTap 로직 그대로 (절대 수정 X)
                  if (userModel == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('user.notLoggedIn'.tr())),
                    );
                    return;
                  }
                  final screen = item.screen;
                  late Widget nextScreen;
                  if (screen is LocalNewsScreen) {
                    nextScreen = LocalNewsScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is MarketplaceScreen) {
                    nextScreen = MarketplaceScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is ClubsScreen) {
                    nextScreen = ClubsScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is FindFriendsScreen) {
                    nextScreen = FindFriendsScreen(userModel: userModel);
                  } else if (screen is JobsScreen) {
                    nextScreen = JobsScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is LocalStoresScreen) {
                    nextScreen = LocalStoresScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is AuctionScreen) {
                    nextScreen = AuctionScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is PomScreen) {
                    nextScreen = PomScreen(
                        userModel: userModel,
                        initialShorts: null,
                        initialIndex: 0);
                  } else if (screen is LostAndFoundScreen) {
                    nextScreen = LostAndFoundScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else if (screen is RealEstateScreen) {
                    nextScreen = RealEstateScreen(
                        userModel: userModel,
                        locationFilter: activeLocationFilter);
                  } else {
                    nextScreen = screen;
                  }
                  onIconTap(nextScreen, item.labelKey);
                },
              );
            }).toList(),
          ),
        ),
        const SliverToBoxAdapter(
            child: Divider(height: 8, thickness: 8, color: Color(0xFFF0F2F5))),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text("main.tabs.newFeed".tr(),
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
          ),
        ),
        FutureBuilder<List<FeedItemModel>>(
          future: FeedRepository().fetchUnifiedFeed(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()));
            }
            if (snapshot.hasError ||
                !snapshot.hasData ||
                snapshot.data!.isEmpty) {
              return SliverToBoxAdapter(
                  child: Center(
                      child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Text("mainFeed.empty".tr()))));
            }
            final feedItems = snapshot.data!;
            // [수정] Provider를 통해 userModel을 하위 위젯에 전달합니다.
            return Provider.value(
              value: userModel,
              child: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => FeedItemCard(
                    item: feedItems[index],
                    onIconTap: onIconTap,
                    allFeedItems: feedItems, // [신규] 전체 피드 리스트 전달
                    currentIndex: index, // [신규] 현재 인덱스 전달
                  ),
                  childCount: feedItems.length,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class FeedItemCard extends StatelessWidget {
  final FeedItemModel item;
  final Function(Widget, String) onIconTap;
  // [신규] 전체 피드 목록과 현재 아이템의 인덱스를 받습니다.
  final List<FeedItemModel> allFeedItems;
  final int currentIndex;

  const FeedItemCard({
    super.key,
    required this.item,
    required this.onIconTap,
    required this.allFeedItems,
    required this.currentIndex,
  });

  @override
  Widget build(BuildContext context) {
    switch (item.type) {
      case FeedItemType.post:
        final post = PostModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return PostCard(post: post);
      case FeedItemType.product:
        final product = ProductModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return ProductCard(product: product);
      case FeedItemType.job:
        final job = JobModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return JobCard(job: job);
      case FeedItemType.auction:
        final auction = AuctionModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return AuctionCard(auction: auction);
      case FeedItemType.club:
        final clubPost = ClubPostModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        final tempClub = ClubModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return ClubPostCard(post: clubPost, club: tempClub);
      case FeedItemType.lostAndFound:
        final lostItem = LostItemModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return LostItemCard(item: lostItem);
      case FeedItemType.pom:
        final short = ShortModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        // [신규] 전체 피드에서 POM 영상만 필터링하여 새로운 리스트를 만듭니다.
        final allShorts = allFeedItems
            .where((feedItem) => feedItem.type == FeedItemType.pom)
            .map((feedItem) => ShortModel.fromFirestore(
                feedItem.originalDoc as DocumentSnapshot<Map<String, dynamic>>))
            .toList();

        // [신규] 현재 POM 영상이 필터링된 리스트에서 몇 번째인지 찾습니다.
        final currentShortIndex = allShorts.indexWhere((s) => s.id == short.id);

        return _ShortFeedCardWithPlayer(
          short: short,
          onCardTap: () {
            final userModel = Provider.of<UserModel?>(context, listen: false);
            // [수정] PomScreen으로 이동 시, 전체 POM 목록과 시작 인덱스를 전달합니다.
            onIconTap(
              PomScreen(
                userModel: userModel,
                initialShorts: allShorts,
                initialIndex: currentShortIndex,
              ),
              'main.tabs.pom',
            );
          },
        );
      case FeedItemType.realEstate:
        final room = RoomListingModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return RoomCard(room: room);
      case FeedItemType.localStores:
        final shop = ShopModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return ShopCard(shop: shop);
      case FeedItemType.findFriends:
        final user = UserModel.fromFirestore(
            item.originalDoc as DocumentSnapshot<Map<String, dynamic>>);
        return FindFriendCard(user: user);
      default:
        return Card(
          child: ListTile(
            title: Text(item.title),
            subtitle: const Text('Unknown item type'),
          ),
        );
    }
  }
}

class _ShortFeedCardWithPlayer extends StatefulWidget {
  final ShortModel short;
  final VoidCallback onCardTap; // Function(Widget, String) -> VoidCallback
  const _ShortFeedCardWithPlayer(
      {required this.short, required this.onCardTap});

  @override
  State<_ShortFeedCardWithPlayer> createState() =>
      _ShortFeedCardWithPlayerState();
}

class _ShortFeedCardWithPlayerState extends State<_ShortFeedCardWithPlayer> {
  VideoPlayerController? _controller;
  Future<void>? _initializeVideoPlayerFuture;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    if (widget.short.videoUrl.isNotEmpty) {
      final videoUri = Uri.parse(widget.short.videoUrl);
      _controller = VideoPlayerController.networkUrl(videoUri);

      _initializeVideoPlayerFuture = _controller!.initialize().then((_) {
        _controller!.setVolume(0);
        _controller!.setLooping(true);
        if (mounted) setState(() {});
      }).catchError((error) {
        debugPrint(
            "===== VideoPlayer Init Error for short ${widget.short.id}: $error =====");
        if (mounted) {
          setState(() {
            _hasError = true;
          });
        }
      });
    } else {
      _hasError = true;
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _UserInfoRow(userId: widget.short.userId),
          GestureDetector(
            onTap: widget.onCardTap, // [수정] 상세 화면 이동을 위해 콜백 함수 호출
            child: VisibilityDetector(
              key: Key(widget.short.id),
              onVisibilityChanged: (visibilityInfo) {
                if (!mounted ||
                    _controller == null ||
                    !_controller!.value.isInitialized ||
                    _hasError) {
                  return;
                }

                var visiblePercentage = visibilityInfo.visibleFraction * 100;
                if (visiblePercentage > 50 && !_controller!.value.isPlaying) {
                  _controller!.play();
                } else if (visiblePercentage < 10 &&
                    _controller!.value.isPlaying) {
                  _controller!.pause();
                }
              },
              child: (_hasError || _controller == null)
                  ? _buildErrorThumbnail()
                  : FutureBuilder(
                      future: _initializeVideoPlayerFuture,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.done &&
                            !_hasError) {
                          return AspectRatio(
                            aspectRatio: _controller!.value.aspectRatio,
                            child: VideoPlayer(_controller!),
                          );
                        } else if (snapshot.hasError) {
                          return _buildErrorThumbnail();
                        } else {
                          return _buildLoadingThumbnail();
                        }
                      },
                    ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Text(
              widget.short.title,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingThumbnail() {
    return Stack(
      alignment: Alignment.center,
      children: [
        if (widget.short.thumbnailUrl.isNotEmpty)
          Image.network(
            widget.short.thumbnailUrl,
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) =>
                _buildErrorThumbnail(),
          ),
        const CircularProgressIndicator(),
      ],
    );
  }

  Widget _buildErrorThumbnail() {
    return const SizedBox(
      height: 200,
      width: double.infinity,
      child:
          Center(child: Icon(Icons.error_outline, color: Colors.red, size: 48)),
    );
  }
}

class _UserInfoRow extends StatelessWidget {
  final String userId;
  const _UserInfoRow({required this.userId});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('users').doc(userId).get(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done &&
            snapshot.hasData &&
            snapshot.data!.exists) {
          final user = UserModel.fromFirestore(
              snapshot.data! as DocumentSnapshot<Map<String, dynamic>>);
          return Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundImage:
                      (user.photoUrl != null && user.photoUrl!.isNotEmpty)
                          ? CachedNetworkImageProvider(user.photoUrl!)
                          : null,
                  child: (user.photoUrl == null || user.photoUrl!.isEmpty)
                      ? const Icon(Icons.person, size: 16)
                      : null,
                ),
                const SizedBox(width: 8),
                Text(
                  user.nickname,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          );
        }
        return const SizedBox(height: 48);
      },
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    if (isEmpty) return "";
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
